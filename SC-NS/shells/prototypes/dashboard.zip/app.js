// Meet AI Dashboard JavaScript - Fixed Version
class MeetAIDashboard {
    constructor() {
        this.currentPage = 'home';
        this.selectedDate = null;
        this.searchQuery = '';
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.initializeCalendar();
        this.loadDashboardData();
        this.setupNotifications();
    }
    
    bindEvents() {
        // Navigation menu items - Fixed
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.handleNavigation(e.currentTarget);
            });
        });
        
        // Search functionality
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.handleSearch(e.target.value);
            });
            
            searchInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    this.performSearch(e.target.value);
                }
            });
        }
        
        // Create meeting button - Fixed
        const createBtn = document.getElementById('createMeetingBtn');
        if (createBtn) {
            createBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.openCreateMeetingModal();
            });
        }
        
        // Modal controls - Fixed
        const closeModal = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const modal = document.getElementById('createMeetingModal');
        
        if (closeModal) {
            closeModal.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.closeCreateMeetingModal();
            });
        }
        
        if (cancelBtn) {
            cancelBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.closeCreateMeetingModal();
            });
        }
        
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeCreateMeetingModal();
                }
            });
        }
        
        // Create meeting form
        const createForm = document.querySelector('.create-meeting-form');
        if (createForm) {
            createForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleCreateMeeting(e);
            });
        }
        
        // Meeting card interactions - Fixed to prevent unwanted navigation
        document.querySelectorAll('.meeting-card').forEach(card => {
            card.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (!e.target.closest('.menu-btn')) {
                    this.handleMeetingCardClick(card);
                }
            });
            
            // Add hover effects
            card.addEventListener('mouseenter', () => {
                this.addHoverEffect(card);
            });
            
            card.addEventListener('mouseleave', () => {
                this.removeHoverEffect(card);
            });
        });
        
        // Meeting card menu buttons - Fixed
        document.querySelectorAll('.meeting-card .menu-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.showMeetingMenu(e.currentTarget);
            });
        });
        
        // Agent card interactions - Fixed
        document.querySelectorAll('.agent-card').forEach(card => {
            // Prevent card click from triggering navigation
            card.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });
        
        // Agent card buttons - Fixed with proper selectors
        document.querySelectorAll('.agent-actions .btn--primary').forEach(btn => {
            if (btn.textContent.includes('Start Meeting')) {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.startMeetingWithAgent(e.currentTarget);
                });
            }
        });
        
        document.querySelectorAll('.agent-actions .btn--outline').forEach(btn => {
            if (btn.textContent.includes('Configure')) {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.configureAgent(e.currentTarget);
                });
            }
        });
        
        document.querySelectorAll('.agent-actions .btn--secondary').forEach(btn => {
            if (btn.textContent.includes('Activate')) {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.activateAgent(e.currentTarget);
                });
            }
        });
        
        // Calendar interactions
        document.querySelectorAll('.calendar-day:not(.empty)').forEach(day => {
            day.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.selectCalendarDate(e.currentTarget);
            });
        });
        
        // Upcoming meeting items
        document.querySelectorAll('.upcoming-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.handleUpcomingMeetingClick(item);
            });
        });
        
        // Sidebar card interactions
        document.querySelectorAll('.sidebar-card .btn-icon').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.handleSidebarAction(e.currentTarget);
            });
        });
        
        // Stats card hover effects
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                this.animateStatCard(card, true);
            });
            
            card.addEventListener('mouseleave', () => {
                this.animateStatCard(card, false);
            });
        });
        
        // Quick stats interactions
        document.querySelectorAll('.quick-stat-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.handleQuickStatClick(item);
            });
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });
        
        // Escape key to close modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeCreateMeetingModal();
            }
        });
        
        // Window resize handler
        window.addEventListener('resize', () => {
            this.handleResize();
        });
    }
    
    // Navigation - Fixed
    handleNavigation(menuItem) {
        // Remove active class from all menu items
        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // Add active class to clicked item
        menuItem.classList.add('active');
        
        // Get page from data attribute
        const page = menuItem.dataset.page;
        this.currentPage = page;
        
        // Update page title and breadcrumb
        this.updatePageHeader(page);
        
        // Show appropriate content
        this.showNotification(`Navigated to ${page.charAt(0).toUpperCase() + page.slice(1)}`, 'success');
        
        // Analytics tracking
        this.trackPageView(page);
    }
    
    updatePageHeader(page) {
        const pageTitle = document.querySelector('.page-title');
        const breadcrumb = document.querySelector('.breadcrumb');
        
        const pageNames = {
            home: 'Dashboard',
            meetings: 'Meetings',
            agents: 'AI Agents',
            analytics: 'Analytics',
            calendar: 'Calendar',
            settings: 'Settings'
        };
        
        if (pageTitle) {
            pageTitle.textContent = pageNames[page] || 'Dashboard';
        }
        
        if (breadcrumb) {
            breadcrumb.innerHTML = `
                <span>Home</span>
                <span class="material-symbols-outlined">chevron_right</span>
                <span>${pageNames[page] || 'Dashboard'}</span>
            `;
        }
    }
    
    // Search functionality
    handleSearch(query) {
        this.searchQuery = query.toLowerCase();
        
        if (query.length > 2) {
            this.performSearch(query);
        } else if (query.length === 0) {
            this.clearSearch();
        }
    }
    
    performSearch(query) {
        const searchResults = this.mockSearch(query);
        this.displaySearchResults(searchResults);
        this.showNotification(`Found ${searchResults.length} results for "${query}"`);
    }
    
    mockSearch(query) {
        const meetings = ['Startup Coaching', 'French Language', 'Technical Interview', 'Creative Brainstorming'];
        const agents = ['Hustle Coach', 'Marie Dubois', 'Tech Mentor', 'Dr. Wellness'];
        
        const results = [];
        
        meetings.forEach(meeting => {
            if (meeting.toLowerCase().includes(query.toLowerCase())) {
                results.push({ type: 'meeting', title: meeting });
            }
        });
        
        agents.forEach(agent => {
            if (agent.toLowerCase().includes(query.toLowerCase())) {
                results.push({ type: 'agent', title: agent });
            }
        });
        
        return results;
    }
    
    displaySearchResults(results) {
        console.log('Search results:', results);
    }
    
    clearSearch() {
        this.showNotification('Search cleared');
    }
    
    // Meeting management - Fixed
    openCreateMeetingModal() {
        const modal = document.getElementById('createMeetingModal');
        if (modal) {
            modal.classList.remove('hidden');
            this.showNotification('Opening create meeting modal...', 'info');
            
            // Focus on first input
            const firstInput = modal.querySelector('input, select');
            if (firstInput) {
                setTimeout(() => firstInput.focus(), 200);
            }
        } else {
            this.showNotification('Modal not found - please check HTML structure', 'error');
        }
    }
    
    closeCreateMeetingModal() {
        const modal = document.getElementById('createMeetingModal');
        if (modal) {
            modal.classList.add('hidden');
            
            // Reset form
            const form = modal.querySelector('form');
            if (form) {
                form.reset();
            }
        }
    }
    
    handleCreateMeeting(e) {
        const formData = new FormData(e.target);
        const meetingData = Object.fromEntries(formData.entries());
        
        this.showNotification('Meeting created successfully! 🎉', 'success');
        this.closeCreateMeetingModal();
        
        setTimeout(() => {
            this.addToUpcomingMeetings(meetingData);
        }, 1000);
    }
    
    addToUpcomingMeetings(meetingData) {
        this.showNotification('Meeting added to your schedule', 'success');
    }
    
    // Meeting card interactions - Fixed
    addHoverEffect(card) {
        card.style.transform = 'translateY(-4px)';
        card.style.boxShadow = 'var(--shadow-lg)';
    }
    
    removeHoverEffect(card) {
        card.style.transform = '';
        card.style.boxShadow = '';
    }
    
    handleMeetingCardClick(card) {
        const status = card.dataset.status;
        const title = card.querySelector('.meeting-title').textContent;
        
        // Remove any existing ripple effects
        const existingRipples = card.querySelectorAll('.ripple-effect');
        existingRipples.forEach(ripple => ripple.remove());
        
        // Add visual feedback without the problematic ripple
        card.style.transform = 'scale(0.98)';
        card.style.transition = 'transform 0.15s ease';
        
        setTimeout(() => {
            card.style.transform = '';
        }, 150);
        
        if (status === 'upcoming') {
            this.showNotification(`Ready to join "${title}"?`, 'info');
        } else if (status === 'completed') {
            this.showNotification(`Opening "${title}" summary...`, 'info');
        } else if (status === 'in_progress') {
            this.showNotification(`Rejoining "${title}"...`, 'success');
        }
    }
    
    showMeetingMenu(button) {
        const options = ['Join Meeting', 'Edit Details', 'Share Link', 'Delete'];
        this.showNotification('Meeting options: ' + options.join(', '));
    }
    
    // Agent management - Fixed
    startMeetingWithAgent(button) {
        const agentCard = button.closest('.agent-card');
        const agentName = agentCard.querySelector('.agent-name').textContent;
        
        this.showNotification(`Starting meeting with ${agentName}...`, 'info');
        
        // Add loading state
        const originalText = button.textContent;
        button.textContent = 'Starting...';
        button.disabled = true;
        button.style.opacity = '0.7';
        
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
            button.style.opacity = '';
            this.showNotification(`Connected to ${agentName}! 🚀`, 'success');
        }, 2000);
    }
    
    configureAgent(button) {
        const agentCard = button.closest('.agent-card');
        const agentName = agentCard.querySelector('.agent-name').textContent;
        
        this.showNotification(`Opening ${agentName} configuration...`, 'info');
    }
    
    activateAgent(button) {
        const agentCard = button.closest('.agent-card');
        const agentName = agentCard.querySelector('.agent-name').textContent;
        const statusElement = agentCard.querySelector('.agent-status');
        
        // Update status
        if (statusElement) {
            statusElement.classList.remove('inactive');
            statusElement.classList.add('active');
            statusElement.innerHTML = '<span class="status-dot"></span><span>Active</span>';
        }
        
        // Update button
        button.textContent = 'Start Meeting';
        button.classList.remove('btn--secondary');
        button.classList.add('btn--primary');
        
        this.showNotification(`${agentName} is now active! ✅`, 'success');
    }
    
    // Calendar functionality
    initializeCalendar() {
        const today = new Date();
        const currentDay = today.getDate();
        
        const todayElement = document.querySelector('.calendar-day.today');
        if (todayElement) {
            this.selectedDate = currentDay;
        }
    }
    
    selectCalendarDate(dayElement) {
        // Remove previous selection
        document.querySelectorAll('.calendar-day').forEach(day => {
            day.classList.remove('selected');
        });
        
        // Add selection to clicked day
        dayElement.classList.add('selected');
        
        const dayNumber = parseInt(dayElement.textContent);
        this.selectedDate = dayNumber;
        
        this.showMeetingsForDate(dayNumber);
        this.showNotification(`Selected August ${dayNumber}, 2025`);
    }
    
    showMeetingsForDate(day) {
        const meetingDays = [27, 28, 30];
        
        if (meetingDays.includes(day)) {
            this.showNotification(`You have meetings scheduled for this day`, 'info');
        } else {
            this.showNotification(`No meetings scheduled for this day`, 'info');
        }
    }
    
    // Upcoming meetings - Fixed
    handleUpcomingMeetingClick(item) {
        const title = item.querySelector('.meeting-title').textContent;
        const time = item.querySelector('.time').textContent;
        
        this.showNotification(`"${title}" scheduled for ${time}`, 'info');
        
        // Simple highlight effect instead of problematic ripple
        const originalBg = item.style.backgroundColor;
        item.style.backgroundColor = 'var(--color-secondary)';
        item.style.transition = 'background-color 0.3s ease';
        
        setTimeout(() => {
            item.style.backgroundColor = originalBg;
        }, 300);
    }
    
    // Sidebar actions
    handleSidebarAction(button) {
        const card = button.closest('.sidebar-card');
        const title = card.querySelector('h3').textContent;
        
        if (title.includes('Calendar')) {
            this.showNotification('Opening full calendar view...', 'info');
        } else if (title.includes('Upcoming')) {
            this.showNotification('Creating new meeting...', 'info');
            this.openCreateMeetingModal();
        } else {
            this.showNotification(`${title} action triggered`, 'info');
        }
    }
    
    // Stats animations
    animateStatCard(card, isHover) {
        const icon = card.querySelector('.material-symbols-outlined');
        const value = card.querySelector('.stat-value');
        
        if (isHover) {
            if (icon) {
                icon.style.transform = 'scale(1.1) rotate(5deg)';
                icon.style.transition = 'transform 0.3s ease';
            }
            if (value) {
                value.style.transform = 'scale(1.05)';
                value.style.transition = 'transform 0.3s ease';
            }
        } else {
            if (icon) {
                icon.style.transform = '';
            }
            if (value) {
                value.style.transform = '';
            }
        }
    }
    
    handleQuickStatClick(item) {
        const label = item.querySelector('.stat-label').textContent;
        this.showNotification(`Viewing detailed ${label.toLowerCase()} analytics...`, 'info');
    }
    
    // Data loading
    loadDashboardData() {
        this.updateStats();
        this.loadRecentActivity();
    }
    
    updateStats() {
        const statValues = document.querySelectorAll('.stat-value');
        
        statValues.forEach((stat, index) => {
            const finalValue = stat.textContent;
            stat.textContent = '0';
            
            setTimeout(() => {
                this.animateNumber(stat, finalValue);
            }, index * 200);
        });
    }
    
    animateNumber(element, finalValue) {
        const isPercent = finalValue.includes('%');
        const isTime = finalValue.includes('m');
        const numericValue = parseInt(finalValue.replace(/[^\d]/g, ''));
        
        let current = 0;
        const increment = Math.ceil(numericValue / 30);
        
        const timer = setInterval(() => {
            current += increment;
            
            if (current >= numericValue) {
                current = numericValue;
                clearInterval(timer);
            }
            
            let displayValue = current.toString();
            if (isPercent) displayValue += '%';
            if (isTime) displayValue += 'm';
            if (finalValue.includes(',')) displayValue = displayValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            
            element.textContent = displayValue;
        }, 50);
    }
    
    loadRecentActivity() {
        setTimeout(() => {
            this.showNotification('Dashboard data loaded successfully', 'success');
        }, 500);
    }
    
    // Keyboard shortcuts
    handleKeyboardShortcuts(e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
            return;
        }
        
        const key = e.key.toLowerCase();
        
        if (e.ctrlKey || e.metaKey) {
            switch (key) {
                case 'k':
                    e.preventDefault();
                    document.querySelector('.search-input')?.focus();
                    break;
                case 'n':
                    e.preventDefault();
                    this.openCreateMeetingModal();
                    break;
            }
        } else {
            switch (key) {
                case '1':
                    e.preventDefault();
                    document.querySelector('[data-page="home"]')?.click();
                    break;
                case '2':
                    e.preventDefault();
                    document.querySelector('[data-page="meetings"]')?.click();
                    break;
                case '3':
                    e.preventDefault();
                    document.querySelector('[data-page="agents"]')?.click();
                    break;
                case '4':
                    e.preventDefault();
                    document.querySelector('[data-page="analytics"]')?.click();
                    break;
                case '5':
                    e.preventDefault();
                    document.querySelector('[data-page="calendar"]')?.click();
                    break;
                case '6':
                    e.preventDefault();
                    document.querySelector('[data-page="settings"]')?.click();
                    break;
            }
        }
    }
    
    // Responsive handling
    handleResize() {
        const width = window.innerWidth;
        
        if (width <= 768) {
            this.enableMobileMode();
        } else {
            this.disableMobileMode();
        }
    }
    
    enableMobileMode() {
        document.body.classList.add('mobile-mode');
    }
    
    disableMobileMode() {
        document.body.classList.remove('mobile-mode');
    }
    
    // Notifications - Fixed
    setupNotifications() {
        const container = document.createElement('div');
        container.id = 'notification-container';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            pointer-events: none;
        `;
        document.body.appendChild(container);
    }
    
    showNotification(message, type = 'info', duration = 3000) {
        const container = document.getElementById('notification-container');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.style.cssText = `
            background-color: var(--color-surface);
            color: var(--color-text);
            padding: 12px 16px;
            border-radius: 8px;
            border: 1px solid var(--color-border);
            box-shadow: var(--shadow-lg);
            margin-bottom: 8px;
            font-size: 14px;
            max-width: 320px;
            transform: translateX(100%);
            transition: transform 0.3s ease;
            pointer-events: auto;
            cursor: pointer;
        `;
        
        // Add type-specific styling
        if (type === 'success') {
            notification.style.borderLeftColor = 'var(--color-success)';
            notification.style.borderLeftWidth = '4px';
        } else if (type === 'error') {
            notification.style.borderLeftColor = 'var(--color-error)';
            notification.style.borderLeftWidth = '4px';
        } else if (type === 'warning') {
            notification.style.borderLeftColor = 'var(--color-warning)';
            notification.style.borderLeftWidth = '4px';
        }
        
        notification.textContent = message;
        container.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Click to dismiss
        notification.addEventListener('click', () => {
            this.dismissNotification(notification);
        });
        
        // Auto dismiss
        setTimeout(() => {
            this.dismissNotification(notification);
        }, duration);
    }
    
    dismissNotification(notification) {
        if (!notification.parentNode) return;
        
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }
    
    // Analytics
    trackPageView(page) {
        console.log(`Page view: ${page}`);
    }
    
    trackEvent(event, data) {
        console.log(`Event: ${event}`, data);
    }
}

// Initialize the dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const dashboard = new MeetAIDashboard();
    
    // Welcome message
    setTimeout(() => {
        dashboard.showNotification('Welcome to Meet AI Dashboard! 🚀', 'success');
    }, 1000);
    
    // Show keyboard shortcuts hint
    setTimeout(() => {
        dashboard.showNotification('Tip: Press Ctrl+K to search, Ctrl+N for new meeting', 'info', 5000);
    }, 3000);
    
    // Make dashboard available globally for debugging
    window.dashboard = dashboard;
});